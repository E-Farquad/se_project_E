package co.edu.unal.se1back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Se1BackApplicationTests {

	@Test
	void contextLoads() {
	}

}
