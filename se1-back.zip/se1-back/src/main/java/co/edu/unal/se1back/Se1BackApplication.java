package co.edu.unal.se1back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Se1BackApplication {

	public static void main(String[] args) {
		SpringApplication.run(Se1BackApplication.class, args);
	}

}
